@echo off
cd %~dp0
cls

SRBMiner-MULTI.exe --algorithm-cpu randomepic --pool eu.epic.iniaku.my.id:3333 --wallet epicwallet --algorithm-cpu xelishashv3 --pool xel.suprnova.cc:3333 --wallet xeliswallet
pause